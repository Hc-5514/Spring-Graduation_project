package com.shop.shoppingbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingbookApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingbookApplication.class, args);
	}

}
