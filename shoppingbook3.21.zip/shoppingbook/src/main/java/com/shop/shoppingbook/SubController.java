package com.shop.shoppingbook;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SubController {

    @GetMapping("/sub")
    public String SubIndex1() {
        return "SubIndex1";
    }
}
