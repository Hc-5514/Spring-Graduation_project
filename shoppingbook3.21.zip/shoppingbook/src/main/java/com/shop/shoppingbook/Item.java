package com.shop.shoppingbook;



public class Item {
private Long id;
private String item;


}
