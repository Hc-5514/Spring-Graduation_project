package com.shop.STYLE.GUIDE.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SubController {

    @GetMapping("/sale")
    public String Sale() {
        return "/layout/salepage";
    }
    @GetMapping("/saledetail")
    public String saledetail() {
        return "/layout/saledetails";
    }
}
