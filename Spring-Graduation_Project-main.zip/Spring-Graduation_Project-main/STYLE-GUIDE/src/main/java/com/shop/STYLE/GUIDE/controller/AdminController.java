package com.shop.STYLE.GUIDE.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AdminController {
    @GetMapping("/admin")
    public String admin() {
        return "adminpage/Admin";
    }

    @GetMapping("/member")
    public String member() {
        return "adminpage/Member";
    }
    @GetMapping("/sales")
    public String sales() {
        return "adminpage/Sales";
    }
    @GetMapping("/upload")
    public String upload() {
        return "adminpage/Upload";
    }



}
