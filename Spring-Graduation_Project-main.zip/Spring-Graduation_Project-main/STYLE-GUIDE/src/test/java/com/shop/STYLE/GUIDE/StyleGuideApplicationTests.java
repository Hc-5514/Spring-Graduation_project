package com.shop.STYLE.GUIDE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StyleGuideApplicationTests {

	@Test
	void contextLoads() {
	}

}
